
import pickle
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

# ---------------- PAGE CONFIG ----------------
st.set_page_config(
    page_title="ClimateScope | Climate Intelligence",
    page_icon="🌍",
    layout="wide"
)

# ---------------- THEME ----------------
st.markdown("""
<style>
.stApp {
    background-color: #FAF8F7;
    color: #302329;
}
[data-testid="stSidebar"] {
    background-color: #4B1028;
}
[data-testid="stSidebar"] * {
    color: white !important;
}
.hero {
    background: linear-gradient(120deg, #4B1028, #852C4B);
    color: white;
    padding: 32px;
    border-radius: 18px;
    margin-bottom: 22px;
}
.hero h1 { color: white; }
.metric-card {
    background: white;
    border: 1px solid #E9DDE2;
    padding: 20px;
    border-radius: 14px;
    min-height: 115px;
}
.metric-label {
    color: #795969;
    font-size: 14px;
}
.metric-value {
    color: #4B1028;
    font-size: 27px;
    font-weight: 700;
}
.section-title {
    color: #4B1028;
    font-weight: 700;
}
</style>
""", unsafe_allow_html=True)

# ---------------- LOAD FILES ----------------
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "nasa_annual_temperature.csv"
MODEL_FILE = BASE_DIR / "climate_model.pkl"

@st.cache_data
def load_data(path):
    data = pd.read_csv(path)
    data["Year"] = pd.to_numeric(data["Year"], errors="coerce")
    data["Temperature_Anomaly"] = pd.to_numeric(
        data["Temperature_Anomaly"], errors="coerce"
    )
    data = data.dropna(
        subset=["Year", "Temperature_Anomaly"]
    ).sort_values("Year")
    return data

@st.cache_resource
def load_model(path):
    with open(path, "rb") as file:
        return pickle.load(file)

if not DATA_FILE.exists() or not MODEL_FILE.exists():
    st.error(
        "Required files are missing. Place the CSV dataset and "
        "climate_model.pkl in the same folder as app.py."
    )
    st.stop()

try:
    df = load_data(str(DATA_FILE))
    model = load_model(str(MODEL_FILE))
except Exception as error:
    st.error(f"Unable to load project files: {error}")
    st.stop()

# ---------------- SIDEBAR ----------------
st.sidebar.title("🌍 ClimateScope")
st.sidebar.caption("Climate Change Intelligence")
page = st.sidebar.radio(
    "NAVIGATION",
    ["Overview", "Temperature Analysis", "ML Prediction", "About"]
)
st.sidebar.divider()
st.sidebar.caption("Data source: NASA GISTEMP")
st.sidebar.caption("Model: Linear Regression")

# ---------------- OVERVIEW ----------------
if page == "Overview":
    st.markdown("""
    <div class="hero">
        <h1>Climate Change Impact Analysis</h1>
        <p>Exploring global temperature trends through NASA data
        and machine learning.</p>
    </div>
    """, unsafe_allow_html=True)

    first_year = int(df["Year"].min())
    last_year = int(df["Year"].max())
    latest = df.iloc[-1]
    trend = df["Temperature_Anomaly"].iloc[-1] - \
            df["Temperature_Anomaly"].iloc[0]

    c1, c2, c3 = st.columns(3)
    metrics = [
        (c1, "YEARS ANALYSED", f"{first_year} – {last_year}"),
        (c2, "ANNUAL RECORDS", f"{len(df):,}"),
        (c3, "LATEST ANOMALY", f"{latest['Temperature_Anomaly']:.2f} °C")
    ]

    for col, label, value in metrics:
        with col:
            st.markdown(
                f'<div class="metric-card">'
                f'<div class="metric-label">{label}</div>'
                f'<div class="metric-value">{value}</div></div>',
                unsafe_allow_html=True
            )

    st.write("")
    st.markdown(
        '<h3 class="section-title">Global Temperature Overview</h3>',
        unsafe_allow_html=True
    )

    fig = px.line(
        df, x="Year", y="Temperature_Anomaly",
        title="Annual Global Temperature Anomalies",
        labels={
            "Year": "Year",
            "Temperature_Anomaly": "Anomaly (°C)"
        }
    )
    fig.add_hline(y=0, line_dash="dash", line_color="#999999")
    fig.update_traces(line_color="#852C4B")
    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        font_color="#302329"
    )
    st.plotly_chart(fig, use_container_width=True)

    st.info(
        "A temperature anomaly is the difference from a reference "
        "period's average, not the actual air temperature."
    )

    st.markdown("### Project objectives")
    st.markdown("""
    - Explore historical global temperature anomalies.
    - Visualize long-term changes in global temperature.
    - Demonstrate a simple machine learning trend model.
    - Communicate evidence-based environmental recommendations.
    """)

# ---------------- TEMPERATURE ANALYSIS ----------------
elif page == "Temperature Analysis":
    st.markdown(
        '<h2 class="section-title">Temperature Analysis</h2>',
        unsafe_allow_html=True
    )

    start_year, end_year = st.slider(
        "Select year range",
        min_value=int(df["Year"].min()),
        max_value=int(df["Year"].max()),
        value=(int(df["Year"].min()), int(df["Year"].max()))
    )

    filtered = df[
        df["Year"].between(start_year, end_year)
    ].copy()

    filtered["10_Year_Average"] = (
        filtered["Temperature_Anomaly"]
        .rolling(window=10, min_periods=1)
        .mean()
    )

    fig = px.line(
        filtered,
        x="Year",
        y="Temperature_Anomaly",
        title="Annual Temperature Anomaly",
        labels={"Temperature_Anomaly": "Anomaly (°C)"}
    )
    fig.add_hline(y=0, line_dash="dash", line_color="#999999")
    fig.update_traces(line_color="#852C4B")
    fig.update_layout(plot_bgcolor="white", paper_bgcolor="white")
    st.plotly_chart(fig, use_container_width=True)

    fig2 = px.line(
        filtered,
        x="Year",
        y="10_Year_Average",
        title="Smoothed Temperature Trend (10-year rolling average)",
        labels={"10_Year_Average": "Rolling average (°C)"}
    )
    fig2.update_traces(line_color="#B88746")
    fig2.update_layout(plot_bgcolor="white", paper_bgcolor="white")
    st.plotly_chart(fig2, use_container_width=True)

    st.markdown("### Annual data")
    st.dataframe(filtered, use_container_width=True)

    st.download_button(
        "Download filtered data as CSV",
        filtered.to_csv(index=False).encode("utf-8"),
        file_name="nasa_temperature_analysis.csv",
        mime="text/csv"
    )

# ---------------- ML PREDICTION ----------------
elif page == "ML Prediction":
    st.markdown(
        '<h2 class="section-title">Temperature Anomaly Prediction</h2>',
        unsafe_allow_html=True
    )
    st.write(
        "Estimate a temperature anomaly by extending the historical "
        "linear trend. This is an educational model, not an official forecast."
    )

    future_year = st.number_input(
        "Select prediction year",
        min_value=2027,
        max_value=2100,
        value=2030,
        step=1
    )

    if st.button("Generate prediction", type="primary"):
        prediction = model.predict(
            pd.DataFrame({"Year": [future_year]})
        )[0]

        st.metric(
            f"Estimated anomaly for {future_year}",
            f"{prediction:.2f} °C"
        )
        st.warning(
            "This estimate extrapolates a straight-line historical trend. "
            "It does not account for emissions scenarios or other climate "
            "drivers and should not be treated as an official forecast."
        )

# ---------------- ABOUT ----------------
elif page == "About":
    st.markdown(
        '<h2 class="section-title">About This Project</h2>',
        unsafe_allow_html=True
    )

    st.write("""
    **Project:** Climate Change Impact Analysis Using Machine Learning

    **Dataset:** NASA GISTEMP global temperature anomalies.

    **Input feature:** Year.

    **Target:** Annual temperature anomaly in degrees Celsius.

    **Algorithm:** Linear Regression.

    **Evaluation:** Mean Absolute Error (MAE) and R² score, calculated
    in the model development notebook.

    **Limitations:** This model uses year alone and cannot represent
    the full physical complexity of the climate system.
    """)

    st.markdown("### Environmental recommendations")
    st.markdown("""
    1. Promote renewable energy and energy efficiency.
    2. Protect forests and restore degraded ecosystems.
    3. Improve climate monitoring and early-warning systems.
    4. Encourage evidence-based climate adaptation planning.
    """)

    st.markdown("### Dataset reference")
    st.markdown(
        "[NASA GISS Surface Temperature Analysis (GISTEMP)]"
        "(https://data.giss.nasa.gov/gistemp/)"
    )

st.sidebar.divider()
st.sidebar.caption("ClimateScope • AIML PBL Project")